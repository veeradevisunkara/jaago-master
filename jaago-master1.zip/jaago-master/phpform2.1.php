<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
<title>jaaGo</title>
  <center> <h2> Load Request Form</h2> </center>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>  

<?php
// define variables and set to empty values
$unit1Err = $lengthErr = $widthErr = $heightErr = $unitsErr = $totallbsErr = $stackErr= $hazardousErr= $tempErr= $fdaErr= "";
$unit1 = $length = $width = $height = $units = $totallbs = $stack= $hazardous= $temp= $fda= "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
  if (empty($_POST["unit1"])) {
    $unit1Err = "unit1 is required";
  } else {
    $unit1 = test_input($_POST["unit1"]);
  }
   if (empty($_POST["length"])) {
    $lengthErr = "length is required";
  } else {
    $length = test_input($_POST["length"]);
  } 
  if (empty($_POST["width"])) {
    $widthErr = "width is required";
  } else {
    $width = test_input($_POST["width"]);
  }
  if (empty($_POST["height"])) {
    $heightErr = "height is required";
  } else {
    $height = test_input($_POST["height"]);
  } 
  if (empty($_POST["units"])) {
    $unitsErr = "units is required";
  } else {
    $units = test_input($_POST["units"]);
  }
  if (empty($_POST["totallbs"])) {
    $totallbsErr = "totallbs is required";
  } else {
    $totallbs = test_input($_POST["totallbs"]);
  }

}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<div class="container">

<h6>Load Info</h6>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
 <div class="form-group ">

      Unit1:
	  <span class="error">* <?php echo $unit1Err;?></span>
      <select id="unit1" class="form-control">

        <option selected>Choose...</option>
        <option>skid</option>
		<option>carton</option>
        <option>drum</option>
		<option>pallet</option>

      </select>

    </div> 

  <span class="error">* <?php echo $lengthErr;?></span>
   <input type="text" name="length" placeholder="length" class="form-control" >
  <br>
  
   <span class="error">* <?php echo $widthErr;?></span>
   <input type="text" name="width"  placeholder="width" class="form-control" >
  <br>
 
  <span class="error">* <?php echo $heightErr;?></span>
   <input type="text" name="height"  placeholder="height" class="form-control" >
  <br>
   <span class="error">* <?php echo $unitsErr;?></span>
   <input type="text" name="units"   placeholder="units"class="form-control" >
  <br>
   <span class="error">* <?php echo $totallbsErr;?></span>
   <input type="text" name="totallbs"   placeholder="totallbs"class="form-control" >
  <br>
  
    
<input type="checkbox" name="stack" value="stack">Okayto Stack<br>
 <input type="checkbox" name="hazardous" value="hazardous">Hazardous<br>
  <input type="checkbox" name="temp" value="temp">Temperature Controlled<br>
  <input type="checkbox" name="fda" value="fda">FDA<br>
Description of commodity: 
<textarea name="datails" class="form-control" rows="5" cols="40"></textarea>
  <br><br>
<br> <input type="checkbox" name="anotherunit" value="anotherunit">anotherunit<br><br>
Additional details about this shipment?: 
<textarea name="additionaldetails" class="form-control" rows="5" cols="40"></textarea>
  <br><br>
  <center> <a href="phpform.php" class="btn btn-primary btn-lg" >PreviousPage</a> 
  <input type="submit" name="submit" value="Submit">  
 
</form>

</div>

</body>
</html>