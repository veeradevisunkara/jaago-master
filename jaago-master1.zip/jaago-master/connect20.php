<?php 
if(isset($_POST['submit'])){
	$id = "0001";
    $to = "veeradevisunkara09@gmail.com"; // this is your Email address
    $from = $_POST['email']; // this is the sender's Email address
   $name = $_POST['name'];
$email = $_POST['email'];
$date = $_POST['date'] ;
$shipfrom = $_POST['shipfrom'];
$shipto = $_POST['shipto'];
$inputservicetype = $_POST['inputservicetype'];
$totalweight = $_POST['totalweight'] ;
$ft = $_POST['ft'];
$floor = $_POST['floor'];
$temp = $_POST['temp'];
$hazardous = $_POST['hazardous'];
$additionaldetails= $_POST['additionaldetails'];
    $subject = "Form submission";
    $subject2 = "Copy of your form submission";
    $message = $name . "  wrote the following:" . "\n\n" . $_POST['email']. $_POST['shipfrom']. $_POST['shipto']. $_POST['inputservicetype']. $_POST['totalweight']. $_POST['ft']. $_POST['floor']. $_POST['temp']. $_POST['hazardous']. $_POST['additionaldetails'];
    $message2 = "Here is a copy of your message " . $name . "\n\n" . $_POST['message'];

    $headers = "From:" . $from;
    $headers2 = "From:" . $to;
    mail($to,$subject,$message,$headers);

// Please specify an SMTP Number 25 and 8889 are valid SMTP Ports.
ini_set("smtp_port","25");
 
 mail($from,$subject2,$message2,$headers2); // sends a copy of the message to the sender
    echo "Mail Sent. Thank you " . $name . ", we will contact you shortly.";
    // You can also use header('Location: thank_you.php'); to redirect to another page.
    }
?>