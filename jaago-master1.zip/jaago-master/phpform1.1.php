<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
<title>jaaGo</title>
  <center> <h2> Load Request Form</h2> </center>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>  

<?php
// define variables and set to empty values
$servicetypeErr = $totalweightErr = $ftErr = $floorErr = $tempErr = $hazardousErr = $additionaldetailsErr= "";
$servicetype = $totalweight = $ft = $floor = $temp = $hazardous=$additionaldetails= "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
  if (empty($_POST["totalweight"])) {
    $totalweightErr = "totalweight is required";
  } else {
    $totalweight = test_input($_POST["totalweight"]);
  }

}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<div class="container">

<h6>Load Info</h6>
<form method="post" action="connect20.php"> 
 <div class="form-group ">

      Service Type:
      <select id="servicetype" class="form-control">

        <option selected>Choose...</option>

        <option>van</option>
		<option>flat dech</option>

      </select>

    </div> 
  Total Weight(lbs):
  <span class="error">* <?php echo $totalweightErr;?></span>
   <input type="text" name="totalweight" class="form-control" >
  <br>
  Ft of Trailer Required:
   <input type="text" name="ft" class="form-control">
  <br>
   Extra Info:  <br><br> 
<input type="checkbox" name="ft" value="ft">Floor Load<br>
  <input type="checkbox" name="temp" value="temp">Temp.Controlled<br>
  <input type="checkbox" name="hazardous" value="hazardous">Hazardous<br>
<br>
Additional details about this shipment?: 
<textarea name="additionaldetails" class="form-control" rows="5" cols="40"></textarea>
  <br><br>
  <center> <a href="phpform.php" class="btn btn-primary btn-lg" >PreviousPage</a> 
  <input type="submit" name="submit" class="btn btn-primary btn-lg" value="Submit">  
 
</form>

</div>

</body>
</html>