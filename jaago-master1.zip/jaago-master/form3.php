<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
<title>jaaGo</title>
  <center> <h2> Load Request Form</h2> </center>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>  

<?php
// define variables and set to empty values
$nameErr = $emailErr = $dateErr = $shipfromErr = $shiptoErr = $genderErr = "";
$name = $email = $date = $shipfrom = $shipto = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
  }
    if (empty($_POST["date"])) {
    $dateErr = "date is required";
  } else {
    $date = test_input($_POST["date"]);
  }
   if (empty($_POST["shipfrom"])) {
    $shipfromErr = "shipfrom isrequired";
  } else {
    $shipfrom = test_input($_POST["shipfrom"]);
  }
    
  if (empty($_POST["shipto"])) {
    $shiptoErr = "shipto isrequired";
  } else {
    $shipto = test_input($_POST["shipto"]);
  }

 
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<div class="container">
<h2>PHP Form Validation Example</h2>

<form method="post" action="phpform2.1.php">  
  Name:
  <span class="error">* <?php echo $nameErr;?></span>
   <input type="text" name="name" class="form-control" >
  <br><br>
  E-mail:
  <span class="error">* <?php echo $emailErr;?></span>
   <input type="email" name="email" class="form-control">
  <br><br>
   Pickup Date:
  <span class="error">* <?php echo $dateErr;?></span>
   <input type="date" name="date" class="form-control">
  <br><br>
  Ship From: 
  <span class="error">*<?php echo $shipfromErr;?></span>
  <input type="text" name="shipfrom" class="form-control">
  <br>
  <input type="text" name="shipfrom" class="form-control">
  <br>
  <div class="form-row">
 <div class= "form-group col-md-6">
 
   <input type="text" name="shipfrom" class="form-control"></div>
   <div class= "form-group col-md-6">
   <input type="text" name="shipfrom" class="form-control"></div>
   </div>
   <br><br>
  Ship To: 
  <span class="error">*<?php echo $shiptoErr;?></span>
  <input type="text" name="shipto" class="form-control">
  <br>
  <input type="text" name="shipto" class="form-control">
  <br>
  <div class="form-row">
 <div class= "form-group col-md-6">
   <input type="text" name="shipto" class="form-control"></div>
   <div class= "form-group col-md-6">
   <input type="text" name="shipto" class="form-control"></div>
   </div>
   <input type="submit" name="submit" class="btn btn-primary btn-lg" value="NextPage">
</form>

</div>

</body>
</html>